## Module Overview

This module provides lang library operations on `stream` values defined by the language specification 2020R1.