## Module Overview

This module provides lang library operations on `query-action`s & `query-expression`s.