## Module Overview

This module provides lang library operations common to all values defined by the language specification 2020R1.
